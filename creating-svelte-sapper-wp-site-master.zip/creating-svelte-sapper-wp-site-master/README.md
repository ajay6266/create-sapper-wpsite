This is a repository for "Creating Svelte, Sapper and WordPress Website" tutorial series. You can [check out the series here](http://watch-learn.com/series/creating-svelte-sapper-and-wordpress-website).

You can go to [releases](https://github.com/ivandoric/creating-svelte-sapper-wp-site/releases) to download the code for most of the videos in the series. Releases are made per episode.
